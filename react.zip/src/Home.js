import { Container, Nav, Navbar, NavDropdown } from 'react-bootstrap';
import React from 'react'
function Home() {
    return (
        <div>
 
 
            <Navbar expand="lg" className="bg-light text-light">
                {/* <Container>
                <Navbar.Brand href="#home"> React-Bootstrap </Navbar.Brand>
                <Navbar.Brand href="#home"> Driving License </Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="ms-auto">
                    <Nav.Link href="/">Home</Nav.Link>
                        <Nav.Link href="/create">Register</Nav.Link>
                        <Nav.Link href="/View">Application status</Nav.Link>
                       
                    </Nav>
                </Navbar.Collapse>
            </Container> */}
 
 
 
 
                <Container>
                    <Navbar.Brand href="#home">Driving License</Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="ms-auto">
                            <Nav.Link href="/">Home</Nav.Link>
                            <Nav.Link href="/create">Register</Nav.Link>
                            <Nav.Link href="/View">Application status</Nav.Link>
                            <Nav.Link href="/View"></Nav.Link>
 
                        </Nav>
                    </Navbar.Collapse>
                </Container>
 
 
 
 
 
 
 
            </Navbar>
 
            <div class="container-fluid bg-dark">
                <div class="row bg-dark text-light">
                    <img src="3.jpg" class="img-fluid" alt="food"></img>
                    <div class="centered font2 text-light">Gate Academy</div>
 
 
                </div>
            </div>
 
            <div class="container-fluid p-3 bg-white">
                <div class="row bg-dark text-light">
                    <div class="col-lg-6 col-md-6 col-sm-12 p-5">
                        <img src="2.jpg" class="img-fluid" alt="food"></img>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 p-5">
                        <h5>Student Gate Academy</h5>
                        <br></br>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officiis recusandae architecto maxime
                            dolore at numquam et dolor quibusdam ex sint quis odit repudiandae atque, est provident dolorum
                            amet ipsa facilis?Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officiis recusandae
                            architecto maxime
                            dolore at numquam et dolor quibusdam ex sint quis odit repudiandae atque, est provident dolorum
                            amet ipsa facilis?
                        </p>
 
 
                    </div>
                </div>
            </div>
 
            <footer>
                <div class="container-fluid bg-dark">
                    <div class="row bg-dark text-light">
                        <div class="col-lg-6 col-md-6 col-sm-12 p-5">
                            <a href="#" class="nav-link p-3"> <i class="fa-solid fa-location-dot "></i> Virudhunagar, tamilNadu</a>
                            <a href="#" class="nav-link p-3"> <i class="fa-solid fa-phone"></i> 987654543</a>
                            <a href="#" class="nav-link p-3"> <i class="fa-solid fa-envelope"></i> gateacademyservice@gmail.com</a>
 
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 p-5">
                            <h5>About the Academy</h5>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Officiis recusandae architecto maxime
                                dolore at numquam et dolor quibusdam ex sint quis odit repudiandae atque, est provident dolorum
                                amet ipsa facilis?</p>
                            <a href="#" class="nav-link p-3"> <i class="fa-brands fa-twitter"></i> &nbsp;
                                <i class="fa-brands fa-facebook"></i> &nbsp;
                                <i class="fa-brands fa-linkedin"></i></a>
 
                        </div>
                    </div>
                </div>
            </footer>
 
 
        </div>
    )
}
export default Home